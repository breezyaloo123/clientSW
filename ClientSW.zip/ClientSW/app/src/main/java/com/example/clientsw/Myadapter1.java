package com.example.clientsw;

import android.widget.Adapter;

public class Myadapter1 {



    public class ViewHolder
    {

    }
}
