package com.example.clientsw.Interfaces;

import com.example.clientsw.Client;
import com.example.clientsw.Shop;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface ShopAPI {
    @GET("produits")
    Call<List<Shop>> getProduits();

    @POST("add")
    Call<Shop> insertProducts(@Body Shop p);

    @PUT("update/{id}")
    Call<Shop> modifyProd(@Path(value = "id") int id);


    @GET("clients")
    Call<List<Client>> getClients();

    @POST("add1")
    Call<Client> insertClients(@Body Client c);


}
